﻿using DionysosFX.Swan.Modules;
using DionysosFX.Swan.Net;
using System.Threading;
using System.Threading.Tasks;

namespace $rootnamespace$.WebModule
{
    public class $safeitemname$ : WebModuleBase
    {
        public override void Start(CancellationToken cancellationToken)
        {

        }

        public override async Task HandleRequestAsync(IHttpContext context)
        {

        }

        public override void Dispose()
        {
        }
    }
}
