﻿using DionysosFX.Swan.Modules;
using DionysosFX.Swan.Net;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class WebModule : WebModuleBase
    {
        public override void Start(CancellationToken cancellationToken)
        {
        }

        public override async Task HandleRequestAsync(IHttpContext context)
        {

        }
    }
}
