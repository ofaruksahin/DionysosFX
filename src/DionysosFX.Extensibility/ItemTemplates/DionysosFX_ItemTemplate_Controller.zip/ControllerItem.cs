﻿using DionysosFX.Module.WebApi;
using DionysosFX.Swan.Routing;

namespace $rootnamespace$.Controller
{
    [Route("/api/$safeitemname$")]
    public class $safeitemname$ : WebApiController
    {
        public $safeitemname$()
        {
            
        }
    }
}
